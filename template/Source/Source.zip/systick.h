#ifndef SYSTICK_H
#define SYSTICK_H

void systickInit(uint16_t frequency);
void delay_ms(uint32_t t);

#endif
